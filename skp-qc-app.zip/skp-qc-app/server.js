/**
 * SKP Merchants QC Test Certificate app — backend server.
 *
 * Stores every certificate in a local SQLite file (data/qc.db) so the
 * data survives restarts and is shared by everyone who opens the app,
 * not just one browser.
 *
 *   npm install
 *   npm start
 *   open http://localhost:3000
 */
const express = require("express");
const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

const db = new Database(path.join(DATA_DIR, "qc.db"));
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS certificates (
    id       TEXT PRIMARY KEY,
    no       TEXT,
    date     TEXT,
    cust     TEXT,
    addr     TEXT,
    mat      TEXT,
    bags     TEXT,
    kgs      TEXT,
    qty      TEXT,
    phys     TEXT,
    s1       TEXT,
    s2       TEXT,
    s3       TEXT,
    chemical TEXT,   -- JSON string of {Si, Mn, C, ...}
    inv      TEXT,
    invd     TEXT,
    ord      TEXT,
    ordd     TEXT,
    truck    TEXT,
    chem     TEXT,   -- chemist's name
    updated  TEXT
  )
`);

const FIELDS = ["id","no","date","cust","addr","mat","bags","kgs","qty","phys",
  "s1","s2","s3","chemical","inv","invd","ord","ordd","truck","chem","updated"];

function rowToRecord(row) {
  if (!row) return row;
  return { ...row, chemical: row.chemical ? JSON.parse(row.chemical) : {} };
}

const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

// List all certificates
app.get("/api/certificates", (req, res) => {
  const rows = db.prepare("SELECT * FROM certificates").all();
  res.json(rows.map(rowToRecord));
});

// Create or update one certificate (id decides which)
app.put("/api/certificates/:id", (req, res) => {
  const id = req.params.id;
  const body = req.body || {};
  const rec = { ...body, id, chemical: JSON.stringify(body.chemical || {}) };
  const cols = FIELDS;
  const placeholders = cols.map(c => "@" + c).join(", ");
  const updateClause = cols.filter(c => c !== "id").map(c => `${c}=excluded.${c}`).join(", ");
  const stmt = db.prepare(`
    INSERT INTO certificates (${cols.join(", ")})
    VALUES (${placeholders})
    ON CONFLICT(id) DO UPDATE SET ${updateClause}
  `);
  const params = {};
  cols.forEach(c => { params[c] = rec[c] !== undefined ? String(rec[c]) : ""; });
  stmt.run(params);
  const saved = db.prepare("SELECT * FROM certificates WHERE id = ?").get(id);
  res.json(rowToRecord(saved));
});

// Delete one certificate
app.delete("/api/certificates/:id", (req, res) => {
  db.prepare("DELETE FROM certificates WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`SKP QC app running at http://localhost:${PORT}`);
});
