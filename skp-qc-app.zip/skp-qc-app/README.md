# SKP Merchants — QC Test Certificate App

A small web app that reproduces the SKP Merchants Pvt. Ltd. paper
"Test Certificate" form, with create/edit, A4 print, PDF download,
CSV export, and a real backend so all certificates are stored on the
server (shared by anyone who opens the app) instead of just one browser.

## Requirements
- Node.js 18 or later

## Setup

```bash
npm install
npm start
```

Then open http://localhost:3000 in a browser.

## How it works
- `server.js` — Express server with a SQLite database (`data/qc.db`,
  created automatically on first run) and a small REST API:
  - `GET    /api/certificates`       — list all certificates
  - `PUT    /api/certificates/:id`   — create or update one certificate
  - `DELETE /api/certificates/:id`   — delete one certificate
- `public/index.html` — the QC certificate app itself (list, form,
  A4 print view, PDF download, CSV export). It talks to the API above
  instead of browser storage, so data is shared across every device
  that opens the app pointed at this server.

## Deploying so others can reach it
Running `npm start` only serves the app on your own machine. To let
colleagues use it from their own computers, run this on a server or a
PC that stays on, and open the right port on your network/firewall,
or deploy it to a hosting provider that runs Node.js apps (Render,
Railway, a VPS, etc.). The `data/qc.db` file is where every
certificate lives — back it up regularly.
